
package paq.pruebas;

import paq.ventanas.Ventana;

/*
 * @author Jesu
 */
public class Main {
    public static void main(String[] args) {
        // Inicio del programa
        new Ventana().setVisible(true);
    }
}
